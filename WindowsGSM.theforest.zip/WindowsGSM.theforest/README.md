# WindowsGSM.theforest
🧩 WindowsGSM plugin for supporting The Forest Dedicated Server



## Requirements

[WindowsGSM](https://github.com/WindowsGSM/WindowsGSM) = 1.21.0


## Installation

* Download the latest [release]()
* Move theforest.cs folder to plugins folder or import theforest_1.0.zip to WindowsGSM
* Click [RELOAD PLUGINS] button or restart WindowsGSM
